package com.nthnode;

class GfG
{
    //Function to find the data of nth node from the end of a linked list.
    int getNthFromLast(Node head, int n)
    {
    	// Your code here
    	 Node node=head;
    int count=0;
    while(node!=null){
        node=node.next;
        count++;
    }
    count=count-n;
    node=head;
    if (count>=0){
        while(count!=0){
            node=node.next;
            count--;
            }
        return node.data;
        }
    else{
        return -1;
    }
   }

    }


