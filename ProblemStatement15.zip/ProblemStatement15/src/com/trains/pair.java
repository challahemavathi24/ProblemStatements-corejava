package com.trains;

// Java program to find minimum number
// of platforms required on a railway station
import java.io.*;
import java.util.*;
 
class pair
{
    int first;
    char second;
     
    pair(int key1, char key2)
    {
        this.first = key1;
        this.second = key2;
    }
}
 
